Skinner Licence

- You can use it free of charge for anything.
- You can’t modify the source (since you don’t have source, you can’t if you tried).
- You can extend / adapt it into your pipeline via it’s API, that’s encouraged.
- You can’t (re)sell it, but you can sell anything made with it.
- By installing/using the Skinner tool you're accepting all repsonsibilities for its usage, and release Eric Pavey from any and all liability.
- © 2022 - All Rights Reserved - Eric Pavey

Anything listed above superseeds the below license. 

https://creativecommons.org/licenses/by/4.0/

https://creativecommons.org/licenses/by/4.0/legalcode
